package eg.edu.guc.santorini.exceptions;

public class InvalidPlacementException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidPlacementException() {
		
	}
	
	public InvalidPlacementException(String e) {
		super(e);
	}
	
	
}
