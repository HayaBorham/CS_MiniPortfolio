package eg.edu.guc.task;

public enum Gender {

	Male, 
	Female;
}
