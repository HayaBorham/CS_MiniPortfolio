package eg.edu.guc.parkei.utilities;

public enum Ticket {
	Micro,
	Mini,
	Maxi;
}
