package eg.edu.guc.parkei.utilities;

public enum Effect {
	Thrilled,
	Happy,
	Angry,
	Bored,
	Wet,
	High,
	Sick,
	Scared;
}
